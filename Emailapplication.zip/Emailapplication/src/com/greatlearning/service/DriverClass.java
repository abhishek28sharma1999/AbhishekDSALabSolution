package com.greatlearning.service;

import java.util.Scanner;

import com.greatlearning.model.Employee;

public class DriverClass {
	public static void main(String[] args) {
		Employee employee = new Employee("Abhishek" , "Sharma");
		String generatedEmail;
		char[] generatedPassword;
		CredetianlService cService = new CredetianlService();
		Scanner scan = new Scanner(System.in);
		int option;
		
		System.out.println("Please enter the Department from the following ");
		System.out.println("1. Technical Department");
		System.out.println("2. Admin Department");
		System.out.println("3. Human Resources Department");
		System.out.println("4. Legal Department");
		
		option = scan.nextInt();
		if (option == 1) {
			generatedEmail = cService.generateEmailAddress(employee.getFirstName(), employee.getLastName(), "Technical");
			generatedPassword = cService.generatePassword();
			cService.showCredentianls(employee , generatedEmail , generatedPassword);
		}
		else if (option == 2) {
			generatedEmail = cService.generateEmailAddress(employee.getFirstName(), employee.getLastName(), "Admin");
			generatedPassword = cService.generatePassword();
			cService.showCredentianls(employee , generatedEmail , generatedPassword);
		}
		else if (option == 3) {
			generatedEmail = cService.generateEmailAddress(employee.getFirstName(), employee.getLastName(), "Human Resource");
			generatedPassword = cService.generatePassword();
			cService.showCredentianls(employee , generatedEmail , generatedPassword);
		}
		else if (option == 4) {
			generatedEmail = cService.generateEmailAddress(employee.getFirstName(), employee.getLastName(), "Legal");
			generatedPassword = cService.generatePassword();
			cService.showCredentianls(employee , generatedEmail , generatedPassword);	
		}
		else {
			System.out.println("Invalid");
		}
		
}
	
}
	
		
	


 